import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CommonService } from '../../../_services/common.service';
import { ApiService } from '../../../_services/api.service';
import { UserService } from 'src/app/_services/user.service';
import { CookieService } from 'ngx-cookie-service';
import { Socket } from 'ngx-socket-io';
import { environment } from '../../../../environments/environment';
@Component({
  selector: 'app-nfc',
  templateUrl: './nfc.component.html',
  styleUrls: ['./nfc.component.css']
})
export class NfcComponent implements OnInit {

  @ViewChild('openModal',  { static: true }) openModal: ElementRef;
  constructor(private http: HttpClient, private socket: Socket, private router: Router, private route: ActivatedRoute, private apiService: ApiService, private commonService: CommonService,
    public userService: UserService,private cookieService: CookieService) { }
    loaderStatus:boolean;
  ngOnInit() {
    this.loaderStatus = true;
    this.route.params.subscribe((params: Params) => {
      // check access code
      if(localStorage.getItem("access_code")) {
        if(localStorage.getItem("access_code")!=params['code']) {
          localStorage.clear();
          //this.socket.disconnect();
          this.cookieService.deleteAll('/','.dinamic.io', true,'Strict');
          sessionStorage.clear();
        }
      }
      // device details
      this.commonService.DEVICE_DETAILS();
      // fullscreen
      // let elem = document.documentElement;
      // let methodToBeInvoked = elem.requestFullscreen || elem['webkitRequestFullScreen'] || elem['mozRequestFullscreen'] || elem['msRequestFullscreen'];
      // if (methodToBeInvoked) methodToBeInvoked.call(elem);
      // access code details
      this.apiService.ACCESS_CODE_DETAILS({"id": 'n', "code": params['code']}).subscribe(result => {
        console.log()
        if(result.status) {
          this.loaderStatus = false;
          let categoryList = result.branch_details[0].categories_list[0].categories;
          let itemsCount = 0;
          for(let i=0; i<categoryList.length; i++) {
            itemsCount += categoryList[i].item_count;
          }
          if(result.dinamic_details.table_type=="location") {
            // location
             let restaurant_details = {
							order_type: "in_house",
							company_id: result.branch_details[0].company_id,
							branch_id: result.branch_details[0]._id,
							floor_id: result.table_detail.floor_id,
							table_id: result.table_detail._id,
							branch_name: result.branch_details[0].name,
              logo_url: result.branch_details[0].logo_url ? (environment.img_url + result.branch_details[0].logo_url) : 'assets/images/Dinamic_Logo.png',
              service_charge : result.branch_details[0].service_charge ? result.branch_details[0].service_charge : '0',
							branch_location: result.branch_details[0].location,
							gst: result.branch_details[0].tax_value,
							restaurant_tax: this.userService.restuarant_taxes,
							valet_service: true,
							session_started_at: result.table_detail.session_started_at,
							offers: [],
							total_items: result.branch_details[0].total_items_count,
							table_order_status: result.table_detail.table_order_status,
							menu_category: categoryList,
							quick_options: result.branch_details[0].quick_options
            }
            localStorage.setItem('restaurant_details', JSON.stringify(restaurant_details));         
            this.userService.restaurant_gst = restaurant_details.gst;
          }
          else {
            // locationless
             let restaurant_details = {
							order_type: "take_aways",
							company_id: result.branch_details[0].company_id,
							branch_id: result.branch_details[0]._id,
							branch_name: result.branch_details[0].name,
							branch_location: result.branch_details[0].location,
              logo_url: result.branch_details[0].logo_url ? (environment.img_url + result.branch_details[0].logo_url) : 'assets/images/Dinamic_Logo.png',
              service_charge : result.branch_details[0].service_charge ? result.branch_details[0].service_charge : '0',
							gst: result.branch_details[0].tax_value,
							restaurant_tax: this.userService.restuarant_taxes,
							valet_service: false,
							offers: [],
							total_items: result.branch_details[0].total_items_count,
							menu_category: categoryList,
							quick_options: result.branch_details[0].quick_options
						}
            localStorage.setItem('restaurant_details', JSON.stringify(restaurant_details));
            this.userService.restaurant_gst = restaurant_details.gst;
          }
          localStorage.setItem('access_code', params['code']);
          localStorage.setItem('access_type', result.dinamic_details.table_type);
          localStorage.setItem('dinamic_details', JSON.stringify(result.dinamic_details));
          this.router.navigate(['/home']);
        }
        else {
          console.log('response', result);
          this.loaderStatus = false;
          let openModal: HTMLElement = this.openModal.nativeElement as HTMLElement;
          openModal.click();
        }
      });
    });
  }

  closeModal(modalName) {
    modalName.hide();
    this.router.navigate(['/']);
  }

}
