import { Routes } from "@angular/router";
import { NfcComponent } from './nfc.component';

export const nfc_routes : Routes = [
    { path : '', component: NfcComponent}
]