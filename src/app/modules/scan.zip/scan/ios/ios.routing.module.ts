import { Routes } from "@angular/router";
import { IosComponent } from './ios.component';

export const ios_routes : Routes = [
    { path: '', component: IosComponent}
]