import { Routes } from "@angular/router";
import { QrComponent } from './qr.component';

export const qr_routes : Routes = [
    { path: '', component: QrComponent}
]