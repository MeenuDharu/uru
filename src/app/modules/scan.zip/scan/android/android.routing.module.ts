import { Routes } from "@angular/router";
import { AndroidComponent } from './android.component';

export const android_routes: Routes = [
    { path: '', component: AndroidComponent}
]