import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CountdownComponent } from 'ngx-countdown';
import { CommonService } from 'src/app/_services/common.service';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/_services/api.service';
import { element } from 'protractor';
import { LoadscriptService } from 'src/app/_services/loadscript.service';
import { Socket } from 'ngx-socket-io';

@Component({
  selector: 'app-valet-status',
  templateUrl: './valet-status.component.html',
  styleUrls: ['./valet-status.component.css']
})
export class ValetStatusComponent implements OnInit {
  config: any = {};
  delayTime: any = '5';
  delayTime_p:any = '5';
  serial_number: any;
  progressValue: any;
  progressPerc: any;
  showFetchingDetails:any;
  resultString:any;
  confirm_click: boolean = true;
  valet_id:any;
  valet_details:any;
  @ViewChild('cd', { static: false }) private countdown: CountdownComponent;
  @ViewChild('closeValett',  { static: true }) closeValett: ElementRef;
  @ViewChild('openValetOpenModal', {static: true}) openValetOpenModal: ElementRef;  
  // @ViewChild('closeValet',  { static: true }) closeValet: ElementRef;
  @ViewChild('openValetStatusOpenModal', {static: true}) openValetStatusOpenModal: ElementRef;  

  constructor(public commonService : CommonService, private router: Router, private apiService : ApiService, private loadScript : LoadscriptService,private socket: Socket) { }

  ngOnInit() { 
    this.confirm_click = true;
    this.loadScript.load('material-icons').then(data => {
      console.log('font awesome reference added....');
    }).catch(error => console.log('err...', error));

console.log("status...........",this.confirm_click)
      
    if(JSON.parse(localStorage.getItem('user_details'))) {
      let a = JSON.parse(localStorage.getItem('user_details')); 
      this.apiService.GET_VALET_DETAILS(a).subscribe( result => {
        console.log('valet result....', result);

        let restaurant_details = JSON.parse(localStorage.getItem('restaurant_details'));
        if(result.status){
this.valet_details = result.data;
          this.commonService.valet_details = result.data;
          this.resultString = result.data.serial_number
          
        
          let data = {
            "vehicle_details" : {
              "branch_id": restaurant_details.branch_id,
              "valet_id" : this.commonService.valet_details._id,  //valet_id adhan angaye potrukey, idhu'la enna data varudhu enga irundhu vardhu
              "serial_number" : result.data.serial_number         
            }
          }     
          //this.commonService.valetStatus = 'awaiting';  
          localStorage.setItem('valet_status', this.commonService.valetStatus);
          console.log("join_valet valet status............")  
     this.socket.emit("join_valet", data); 
 //  this.router.navigate(['/valet/status']);
     
      }
      else
      {
        this.router.navigate(['/']);
     
      }
      })
     } 
    
  }


  
  cancelValet(){
   
    if(this.valet_details){
      this.apiService.CANCEL_VALET({ _id : this.valet_details._id}).subscribe( result => {
        console.log('result....', result);
        this.valet_details = undefined;
        this.commonService.valet_details = undefined;
        this.router.navigate[('/')]
      })
    }
    
  }
  setPlusFive(){  
    let d = this.plusDate( new Date(), 5); 
    let c = this.setDeliveryNew(d);
    return c;
  }
  setPlusTen(){
    let d = this.plusDate( new Date(), 10);
    let c = this.setDeliveryNew(d);
    return c;
  }
  setPlusFifteen(){ 
    let d = this.plusDate( new Date(), 15);
    let c = this.setDeliveryNew(d);
    return c;
  }
  setPlusTwenty(){
    let d = this.plusDate( new Date(), 20);
    let c = this.setDeliveryNew(d);
    return c;
  }

  plusDate(dt, minutes) {   
    return new Date(dt.getTime() + minutes*60000);
}

  setDelivery(){ 
    let d = new Date(this.commonService.deliveryTime);
    let hours = d.getHours();
    let minutes = d.getMinutes();     

    var ampm = hours >= 12 ? 'pm' : 'am';
    // console.log('hrs....', hours);
    // console.log('minutes...', minutes);
    let hrs = hours % 12;
    let a = hrs ? hrs : 12; // the hour '0' should be '12'
    let mins = minutes < 10 ? '0'+minutes : String(minutes);
    var strTime = a + ':' + mins + ' ' + ampm;
    return strTime;
 
  }

  setDeliveryNew(date){ 
    let d = date;
    let hours = d.getHours();
    let minutes = d.getMinutes();     

    var ampm = hours >= 12 ? 'pm' : 'am';
    // console.log('hrs....', hours);
    // console.log('minutes...', minutes);
    let hrs = hours % 12;
    let a = hrs ? hrs : 12; // the hour '0' should be '12'
    let mins = minutes < 10 ? '0'+minutes : String(minutes);
    var strTime = a + ':' + mins + ' ' + ampm;
    return strTime;
 
  }

  closeValet(){
    // console.log('result string...');
    let closeValett: HTMLElement = this.closeValett.nativeElement as HTMLElement;
    closeValett.click();
  }

  openPop(){   
    let openValetModal: HTMLElement = this.openValetOpenModal.nativeElement as HTMLElement;
    openValetModal.click();
  }
  openStatusPop(){   
    let openValetStatusModal: HTMLElement = this.openValetStatusOpenModal.nativeElement as HTMLElement;
    openValetStatusModal.click();
  }

  backToMenu(){
    // localStorage.removeItem('re_request');
    this.router.navigate(['/home']);    
  }

  requestAgain(){
    let valet_details = JSON.parse(localStorage.getItem('valet_details'));

    this.serial_number = this.commonService.valet_details.serial_number
    this.delayTime = '5';
    this.openPop();
  }

  radioChange(event){
console.log('delay time....', event);
  }

  contactManager(){
    // console.log('contact manager....');
  }

  vehicleReq(){
    let a = localStorage.getItem('re_request');
    if(a){
      if(a == '1'){
        return false;
      }else{
        return true;
      }
    }else{
      return true;
    }
  }
  vehicleReReq(){
    let a = localStorage.getItem('re_request');
    if(a){
      if(a == '1'){
        return true;
      }else{
        return false;
      }
    }else{
      return false;
    }

  }



  onConfirm1(){    
    console.log("confirm1")
    this.confirm_click = false;
    let restaurant_details = JSON.parse(localStorage.getItem('restaurant_details'));
    let user_details = JSON.parse(localStorage.getItem('user_details'));
    //valetStatusModal.show();
    this.commonService.valetStatus = 'awaiting';         
    
    localStorage.setItem('valet_status', this.commonService.valetStatus);
    console.log(this.commonService.valet_details._id)
    let data = {
      "vehicle_details" : {
        "branch_id": restaurant_details.branch_id,
        "valet_id" : this.commonService.valet_details._id,
        "serial_number" : this.resultString,
        "requested_delay": Number(this.delayTime),
        // "delivery_time": "Thu Feb 06 2020 14:19:27 GMT+0530 (India Standard Time)",
        "delivery_time": Date.now(),
        "user_details": {
          "name": user_details.name,
            "contact_number": user_details.mobile,
            "email": user_details.email
        }
      }
    }  
    console.log("Valet data..........", data)  ;
    this.apiService.VALET_CONFIRM(data).subscribe(result => {
      console.log('result....', result);
      if(result.status){
        localStorage.setItem('valet_details', JSON.stringify(result.data));
        this.apiService.UPDATE_VALET_STATUS({ valet_id : this.commonService.valet_details._id, valet_status : 'awaiting' }).subscribe( result => {
          console.log('result.....', result);
          this.router.navigate(['/bill/confirm']);
        })
      }
    });

  }


}
