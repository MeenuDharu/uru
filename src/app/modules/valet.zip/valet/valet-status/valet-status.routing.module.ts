import { Routes } from '@angular/router';
import { ValetStatusComponent } from './valet-status.component';

export const valet_status_routes : Routes = [
    { path: '', component: ValetStatusComponent}
]