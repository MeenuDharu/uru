import { Routes } from "@angular/router";
import { ValetQrComponent } from './valet-qr.component';

export const valetqr_routes : Routes = [
    { path: '', component: ValetQrComponent}
]

