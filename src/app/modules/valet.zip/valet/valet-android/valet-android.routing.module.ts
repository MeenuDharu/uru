import { Routes } from '@angular/router';
import { ValetAndroidComponent } from './valet-android.component';

export const valet_android_routes : Routes = [
    { path: '', component: ValetAndroidComponent}
]