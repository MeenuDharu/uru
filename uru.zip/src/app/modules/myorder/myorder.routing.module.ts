import { Routes } from '@angular/router';
import { MyorderComponent } from './myorder.component';

export const myorder_routes : Routes = [
    { path: '', component: MyorderComponent}
]