import { Routes } from '@angular/router';
import { FeedbackComponent } from './feedback.component';

export const feedback_routes : Routes = [
    { path: '', component: FeedbackComponent}
]