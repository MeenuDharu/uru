import { Routes } from '@angular/router';
import { PickupComponent } from './pickup.component';

export const pickup_routes : Routes = [
    { path: '', component: PickupComponent}
]