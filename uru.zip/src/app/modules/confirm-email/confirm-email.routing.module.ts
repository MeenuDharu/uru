import { Routes } from '@angular/router';
import { ConfirmEmailComponent } from './confirm-email.component';

export const confirm_email_routes : Routes = [
    { path: '', component: ConfirmEmailComponent}
]