import { Routes } from '@angular/router';
import { SocialAuthComponent } from './social-auth.component';

export const social_auth_routes : Routes = [
    { path: '', component: SocialAuthComponent}
]