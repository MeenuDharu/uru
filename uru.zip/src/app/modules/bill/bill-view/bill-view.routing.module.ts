import { Routes } from '@angular/router';
import { BillViewComponent } from './bill-view.component';

export const bill_view_routes : Routes = [
    { path : '', component: BillViewComponent}
]