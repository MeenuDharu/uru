import { Routes } from '@angular/router';
import { BillTypeComponent } from './bill-type.component';

export const bill_type_routes : Routes = [
    { path: '', component: BillTypeComponent}
]