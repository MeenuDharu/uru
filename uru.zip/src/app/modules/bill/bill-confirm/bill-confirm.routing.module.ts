import { Routes } from '@angular/router';
import { BillConfirmComponent } from './bill-confirm.component';

export const bill_confirm_routes : Routes = [
    { path: '', component: BillConfirmComponent}
]