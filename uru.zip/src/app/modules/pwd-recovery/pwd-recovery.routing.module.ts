import { Routes } from "@angular/router";
import { PwdRecoveryComponent } from './pwd-recovery.component';

export const pwdrecovery_routes: Routes = [
    { path: '', component: PwdRecoveryComponent}
];