import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CompletedOrderComponent } from './completed-order.component'



export const completed_order_routes : Routes = [
  { path: '', component: CompletedOrderComponent}
]