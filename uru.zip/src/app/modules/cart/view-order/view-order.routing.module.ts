import { Routes } from '@angular/router';
import { ViewOrderComponent } from './view-order.component';

export const view_order_routes : Routes = [
    { path: '', component: ViewOrderComponent}
]