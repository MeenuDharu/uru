import { Routes } from '@angular/router';
import { TakeawayOrderComponent } from './takeaway-order.component';

export const takeaway_order_routes : Routes = [
    { path: '', component: TakeawayOrderComponent}
]