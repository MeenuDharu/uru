import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LiveOrderComponent } from './live-order.component'


export const live_order_routes : Routes = [
  { path: '', component: LiveOrderComponent}
]