import { Routes } from '@angular/router';
import { OrderStatusComponent } from './order-status.component';

export const order_status_routes : Routes = [
    { path: '', component: OrderStatusComponent}
]