import { Routes } from '@angular/router';
import { OffersComponent } from './offers.component';

export const offer_routes : Routes = [
    { path: '', component: OffersComponent}
]