import { Routes } from '@angular/router';
import { SectionsComponent } from './sections.component';


export const sections_routes : Routes = [
  { path:'', component: SectionsComponent}
]