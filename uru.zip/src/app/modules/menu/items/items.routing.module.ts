import { Routes } from '@angular/router';
import { ItemsComponent } from './items.component';

export const items_routes : Routes = [
    { path: '', component: ItemsComponent}
]