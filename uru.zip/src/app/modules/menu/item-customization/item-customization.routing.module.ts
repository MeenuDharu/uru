import { Routes } from '@angular/router';
import { ItemCustomizationComponent } from './item-customization.component';

export const item_customization_routes : Routes = [
    { path: '', component: ItemCustomizationComponent}
]