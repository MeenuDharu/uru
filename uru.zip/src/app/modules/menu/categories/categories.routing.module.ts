import { Routes } from '@angular/router';
import { CategoriesComponent } from './categories.component';

export const categories_routes : Routes = [
    { path:'', component: CategoriesComponent}
]