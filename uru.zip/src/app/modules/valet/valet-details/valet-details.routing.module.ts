import { Routes } from '@angular/router';
import { ValetDetailsComponent } from './valet-details.component';

export const valet_details_routes : Routes = [
    { path: '', component: ValetDetailsComponent }
]