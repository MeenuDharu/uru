import { Routes } from '@angular/router';
import { ValetIosComponent } from './valet-ios.component';

export const valet_ios_routes : Routes = [
    { path: '', component: ValetIosComponent}
]