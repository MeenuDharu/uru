function newFunction(){
    console.log("Callback works.....");
}